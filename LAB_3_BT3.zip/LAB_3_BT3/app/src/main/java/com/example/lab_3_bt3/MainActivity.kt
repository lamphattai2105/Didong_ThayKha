package com.example.lab_3_bt3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.CheckBox
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val cb = findViewById<CheckBox>(R.id.cb1)
        cb.setOnCheckedChangeListener { buttonView, isChecked ->
            Toast.makeText(this, "Checked = " + isChecked.toString(), Toast.LENGTH_LONG).show()
        }
    }
}
