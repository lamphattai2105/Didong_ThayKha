package com.example.lab_6_bt1b

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnChuyen.setOnClickListener{
            val intent : Intent = Intent(this, Main_2_B_Activity::class.java)

            startActivityForResult(intent, 202)
        }

        btnNhan.setOnClickListener{
            val intentNhan = intent
            val data : String = intentNhan.getStringExtra("data")
            Toast.makeText(this, data.toString(), Toast.LENGTH_SHORT ).show()
        }
    }
}
