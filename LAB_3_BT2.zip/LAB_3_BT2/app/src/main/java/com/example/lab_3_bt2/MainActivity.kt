package com.example.lab_3_bt2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    lateinit var btnShow : Button
    lateinit var txtResult : TextView
    lateinit var rBG : RadioGroup
    lateinit var choosedText : String
    lateinit var radioGroup : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnShow = findViewById(R.id.btnShow)
        txtResult = findViewById(R.id.txtviewShow)
        rBG = findViewById(R.id.raGroup)
        rBG.setOnCheckedChangeListener { group, checkedId ->
            val rb = findViewById<RadioButton>(checkedId)
            choosedText = rb.text.toString()
        }
        btnShow.setOnClickListener {
            var t = String.format(getString(R.string.result_title),choosedText)
            txtResult.text = t
        }
    }
}
