package com.example.asynctask

import android.content.Context
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.SystemClock
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        btnXuli.setOnClickListener{
            xuLiCongViec().execute()
        }
    }
    inner class xuLiCongViec : AsyncTask<Void, String, String>(){


        override fun onPreExecute(){
            super.onPreExecute()
            txtNoiDung.text= "Bắt đầu công việc \n"
        }
        override fun doInBackground(vararg params: Void?) : String{
            for(i in 1..10){
                publishProgress("Xong việc $i \n")
            }
//            txtNoiDung.text = ""
            return "Kết thúc công việc"
        }

        override fun onPostExecute(result: String?){
            super.onPostExecute(result)
            txtNoiDung.append(result)
        }

        override fun onProgressUpdate(vararg values: String?) {
            super.onProgressUpdate(*values)
            txtNoiDung.append(values[0])
        }
    }
}
