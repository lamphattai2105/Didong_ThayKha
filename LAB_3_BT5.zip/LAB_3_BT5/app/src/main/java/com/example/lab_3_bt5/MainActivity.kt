package com.example.lab_3_bt5

import android.content.DialogInterface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var builder : AlertDialog.Builder
        builder = AlertDialog.Builder(this)
        btnDelete.setOnClickListener {
            builder.setMessage("Bạn có muốn thoát khỏi trình duyệt?")
                .setPositiveButton("Đồng ý", DialogInterface.OnClickListener { dialog, id -> finish()
                    Toast.makeText(applicationContext, "Bạn chọn đồng ý", Toast.LENGTH_SHORT).show()
                })
                .setNegativeButton("Hủy", DialogInterface.OnClickListener { dialog, id -> dialog.cancel()
                    Toast.makeText(applicationContext, "Bạn chọn hủy", Toast.LENGTH_LONG).show()
                })

            val ialert = builder.create()
            ialert.setTitle("Thông báo")
            ialert.show()
        }
    }
}
