package com.example.lab_6_bt1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main2.*

class Main2Activity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)

//              *************************************************


        val intent = intent
        val hoten:String = intent.getStringExtra("key")
        txtView.text = hoten


        back.setOnClickListener{
            backForResult()
        }

        }

        fun backForResult(){
            val intent = getIntent()
            intent.putExtra("data", "This is Intent For Result")
            setResult(202, intent)
            finish()
        }
    }

