package com.example.lab_3_bt1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtview = findViewById<TextView>(R.id.textView)
        txtview.setText("Hello World")

        var count: Int = 0;
        val btnClick = findViewById<Button>(R.id.btnClick)
        val txtView = findViewById<TextView>(R.id.textView)
        btnClick.setOnClickListener {
            count++;
            txtview.setText(count.toString())
        }
        val btnDelete = findViewById<Button>(R.id.btnClickDelete)
        btnDelete.setOnClickListener {
            if (count > 0) {
                count--;
                txtview.setText(count.toString())
            }
            if(count==0){
                txtview.setText("Good morning")
            }
        }
    }
}
