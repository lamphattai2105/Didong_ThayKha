package com.example.broadcastreceivers

import android.content.Context
import android.net.ConnectivityManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.widget.Toast

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val c = applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfo = c.activeNetworkInfo
        if (networkInfo!= null && networkInfo.isConnected){
            if(networkInfo.type==ConnectivityManager.TYPE_MOBILE){
                Toast.makeText(applicationContext, "Connected to mobile", Toast.LENGTH_LONG).show()
            }
            if(networkInfo.type==ConnectivityManager.TYPE_WIFI){
                Toast.makeText(applicationContext, "Connected to wifi", Toast.LENGTH_LONG).show()
            }
        }
        else{
            val toast = Toast.makeText(applicationContext, "You are offline", Toast.LENGTH_LONG)
            toast.setGravity(Gravity.CENTER, 0, 0 )
            toast.show()
//            Toast.makeText(applicationContext, "You are offline", Toast.LENGTH_LONG).show()
        }
    }
}
